package com.example.aquib.navigationdrawer;

import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.aquib.navigationdrawer.Fragment.CameraFragment;
import com.example.aquib.navigationdrawer.Fragment.GalleryFragment;
import com.example.aquib.navigationdrawer.Fragment.ManageFragment;
import com.example.aquib.navigationdrawer.Fragment.ManagmentFragment;
import com.example.aquib.navigationdrawer.Fragment.SendFragment;
import com.example.aquib.navigationdrawer.Fragment.ShareFragment;
import com.example.aquib.navigationdrawer.Fragment.SlideShowFragment;

public class MainApp extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
ImageView toolbarImage;
    ActionBarDrawerToggle toggle;
    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_app);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbarImage =(ImageView) toolbar.findViewById(R.id.toolbar_camera);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
         toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        displaySelectedScreen(R.id.nav_camera);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_app, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        if (id == R.id.action_cancel) {
            Toast.makeText(this, "you selected cancel", Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //Go to menu then activity_main_app to customise your drawer
    //Go to main_app to cutomise your 3 dots icon items

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {


        //calling the method displayselectedscreen and passing the id of selected menu
        displaySelectedScreen(item.getItemId());
        //make this method blank

        return true;
    }

    private void displaySelectedScreen(int itemId) {

        //creating fragment object
        Fragment fragment = null;

        //initializing the fragment object which is selected
        switch (itemId) {
            case R.id.nav_camera:
                toolbarImage.setVisibility(View.VISIBLE);
                fragment = new CameraFragment();
                break;
            case R.id.nav_gallery:
                toolbarImage.setVisibility(View.GONE);
                fragment = new GalleryFragment();
                break;
            case R.id.nav_manage:
                toolbarImage.setVisibility(View.GONE);
                fragment = new ManageFragment();
                break;
            case R.id.nav_management:
                toolbarImage.setVisibility(View.GONE);
                fragment = new ManagmentFragment();
                break;
            case R.id.nav_share:
                toolbarImage.setVisibility(View.GONE);
                fragment = new ShareFragment();
                break;
            case R.id.nav_send:
                toolbarImage.setVisibility(View.GONE);
                fragment = new SendFragment();
                break;
            case R.id.nav_slideshow:
                toolbarImage.setVisibility(View.GONE);
                fragment = new SlideShowFragment();
                break;
        }

        //replacing the fragment
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.content_frame, fragment);
            ft.commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }
}
